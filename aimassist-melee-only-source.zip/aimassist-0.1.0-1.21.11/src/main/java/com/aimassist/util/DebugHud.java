package com.aimassist.util;

import com.aimassist.AimAssistClient;
import com.aimassist.config.AimConfig;
import com.aimassist.core.AimController;
import com.aimassist.core.MouseDelta;
import com.aimassist.core.TargetCandidate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

public final class DebugHud {

    private static final int WHITE = 0xFFFFFFFF;
    private static final int GREEN = 0xFF55FF55;
    private static final int RED = 0xFFFF5555;
    private static final int YELLOW = 0xFFFFFF55;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int AQUA = 0xFF55FFFF;
    private static final int ORANGE = 0xFFFFAA00;

    private DebugHud() {
    }

    public static void render(DrawContext context) {
        if (!AimConfig.debugHud) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.options.hudHidden) {
            return;
        }

        AimController controller = AimAssistClient.CONTROLLER;
        List<TargetCandidate> candidates = controller.getCandidates();
        TargetCandidate selected = controller.getSelected();

        int x = 6;
        int y = 6;
        int step = 10;

        String state = AimConfig.enabled ? "ON" : "OFF";
        context.drawTextWithShadow(client.textRenderer,
                "AimAssist  " + state + "  " + controller.getStatusText(), x, y,
                selected != null ? GREEN : (AimConfig.enabled ? YELLOW : GRAY));
        y += step;

        context.drawTextWithShadow(client.textRenderer,
                String.format("气泡 范围=%.1f格 夹角=%.1f°  移动=%.3f格/tick(%s)",
                        AimConfig.range, AimConfig.fov,
                        controller.getPlayerSpeed(), controller.isPlayerMoving() ? "在动" : "静止"),
                x, y, AQUA);
        y += step;

        context.drawTextWithShadow(client.textRenderer,
                String.format("权重 距离=%.2f 夹角=%.2f  加成 玩家=%.2f 敌对=%.2f  死区=%.2f° 平滑=%.2f",
                        AimConfig.weightDistance, AimConfig.weightAngle,
                        AimConfig.tierBonusPlayer, AimConfig.tierBonusHostile,
                        AimConfig.deadzone, AimConfig.smoothing),
                x, y, GRAY);
        y += step;

        drawControllerLine(context, client, controller, x, y);
        y += step;

        if (candidates.isEmpty()) {
            context.drawTextWithShadow(client.textRenderer, "候选: (无)", x, y, GRAY);
            y += step;
        } else {
            int shown = Math.min(candidates.size(), controller.getHudMaxCandidates());
            for (int i = 0; i < shown; i++) {
                TargetCandidate candidate = candidates.get(i);
                boolean isSelected = candidate == selected;
                context.drawTextWithShadow(client.textRenderer,
                        (isSelected ? "> " : "  ") + candidate.describe(), x, y,
                        isSelected ? GREEN : WHITE);
                y += step;
            }
            if (candidates.size() > shown) {
                context.drawTextWithShadow(client.textRenderer,
                        "  ...还有 " + (candidates.size() - shown) + " 个", x, y, GRAY);
                y += step;
            }
        }

        drawBubbleRing(context, client, controller, selected);
    }

    /**
     * 控制器读数。强度 k、P/D 各贡献多少度每秒、这一帧实际转了多少度，
     * 以及这一 tick 里跑了多少渲染帧 —— 最后这个数直接反映逐帧是否生效。
     */
    private static void drawControllerLine(DrawContext context, MinecraftClient client,
                                           AimController controller, int x, int y) {
        MouseDelta.Correction correction = controller.getLastCorrection();
        boolean assisting = controller.getSelected() != null && controller.getAssistScale() > 0.0D;
        String text = String.format(
                "控制器 强度=%.0f%%  P=%.0f°/s  D=%.0f°/s  本帧=%+.3f°  %d帧/tick",
                controller.getAssistScale() * 100.0D,
                controller.getLastPRate(), controller.getLastDRate(),
                correction.deltaYaw(), controller.getFramesLastTick());
        context.drawTextWithShadow(client.textRenderer, text, x, y, assisting ? GREEN : GRAY);
    }

    private static void drawBubbleRing(DrawContext context, MinecraftClient client,
                                       AimController controller, TargetCandidate selected) {
        double radius = controller.getBubbleRadiusPixels();
        if (radius < 2.0D || radius > 4000.0D) {
            return;
        }

        int color;
        if (!AimConfig.enabled) {
            color = GRAY;
        } else if (selected != null) {
            color = GREEN;
        } else if (!controller.getCandidates().isEmpty()) {
            color = ORANGE;
        } else {
            color = GRAY;
        }

        int cx = client.getWindow().getScaledWidth() / 2;
        int screenHeight = client.getWindow().getScaledHeight();
        int half = (int) Math.round(radius);

        // 触发范围是水平楔形（Y 轴不参与），所以画左右两条竖线，不画圆。
        for (int side = -1; side <= 1; side += 2) {
            int px = cx + side * half;
            context.fill(px - 1, 0, px + 2, screenHeight, color);
        }
    }
}
