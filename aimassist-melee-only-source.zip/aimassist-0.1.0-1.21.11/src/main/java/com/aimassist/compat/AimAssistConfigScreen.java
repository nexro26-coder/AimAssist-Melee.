package com.aimassist.compat;

import com.aimassist.config.AimConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.Locale;

/**
 * 所有参数都在这里轮换档位。两列铺开，一屏放得下，不需要滚动。
 *
 * <p>1.21.9+ 的 Screen 框架自己会画背景（含模糊），这里<b>不要</b>再调
 * renderBackground —— 会在同一帧模糊第二次，直接崩 Can only blur once per frame。
 */
public class AimAssistConfigScreen extends Screen {

    private static final int COL_W = 150;
    private static final int ROW_H = 18;
    private static final int GAP = 20;
    private static final int ROWS = 12;
    private static final int COL_GAP = 4;

    private final Screen parent;

    public AimAssistConfigScreen(Screen parent) {
        super(Text.literal("AimAssist 设置"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - COL_W - COL_GAP / 2;
        int right = this.width / 2 + COL_GAP / 2 + (COL_GAP % 2);
        int top = Math.max(28, (this.height - ROWS * GAP) / 2 - 6);

        int row = 0;
        addBool(left, top + row * GAP, "总开关",
                v -> v ? "开" : "关",
                () -> AimConfig.enabled, v -> AimConfig.enabled = v);
        row++;

        addBool(left, top + row * GAP, "仅持近战武器生效",
                v -> v ? "开" : "关",
                () -> AimConfig.requireMeleeWeapon, v -> AimConfig.requireMeleeWeapon = v);
        row++;

        addNum(left, top + row * GAP, "辅助强度上限", AimConfig.CAP_STEPS,
                v -> String.format(Locale.ROOT, "%.0f%%", v * 100.0D),
                () -> AimConfig.assistCap, v -> AimConfig.assistCap = v);
        row++;

        addNum(left, top + row * GAP, "最大辅助角速度", AimConfig.SPEED_STEPS,
                v -> String.format(Locale.ROOT, "%.0f °/s", v),
                () -> AimConfig.maxAssistSpeed, v -> AimConfig.maxAssistSpeed = v);
        row++;

        addNum(left, top + row * GAP, "饱和角速度", AimConfig.OMEGA_REF_STEPS,
                v -> String.format(Locale.ROOT, "%.0f °/s", v),
                () -> AimConfig.omegaRef, v -> AimConfig.omegaRef = v);
        row++;

        addNum(left, top + row * GAP, "强度下限", AimConfig.STRENGTH_FLOOR_STEPS,
                v -> String.format(Locale.ROOT, "%.0f%%", v * 100.0D),
                () -> AimConfig.strengthFloor, v -> AimConfig.strengthFloor = v);
        row++;

        addNum(left, top + row * GAP, "收敛速度", AimConfig.P_RATE_STEPS,
                v -> String.format(Locale.ROOT, "%.0f /s", v),
                () -> AimConfig.pRate, v -> AimConfig.pRate = v);
        row++;

        addNum(left, top + row * GAP, "触发距离", AimConfig.RANGE_STEPS,
                v -> String.format(Locale.ROOT, "%.1f 格", v),
                () -> AimConfig.range, v -> AimConfig.range = v);
        row++;

        addNum(left, top + row * GAP, "气泡夹角", AimConfig.FOV_STEPS,
                v -> String.format(Locale.ROOT, "%.1f°", v),
                () -> AimConfig.fov, v -> AimConfig.fov = v);
        row++;

        addNum(left, top + row * GAP, "退出迟滞", AimConfig.HYSTERESIS_STEPS,
                v -> String.format(Locale.ROOT, "×%.2f", v),
                () -> AimConfig.exitHysteresis, v -> AimConfig.exitHysteresis = v);
        row++;

        addNum(left, top + row * GAP, "距离权重", AimConfig.WEIGHT_STEPS,
                v -> String.format(Locale.ROOT, "%.1f", v),
                () -> AimConfig.weightDistance, v -> AimConfig.weightDistance = v);
        row++;

        addNum(left, top + row * GAP, "夹角权重", AimConfig.WEIGHT_STEPS,
                v -> String.format(Locale.ROOT, "%.1f", v),
                () -> AimConfig.weightAngle, v -> AimConfig.weightAngle = v);

        row = 0;
        addNum(right, top + row * GAP, "玩家加成", AimConfig.TIER_PLAYER_STEPS,
                v -> String.format(Locale.ROOT, "+%.1f", v),
                () -> AimConfig.tierBonusPlayer, v -> AimConfig.tierBonusPlayer = v);
        row++;

        addNum(right, top + row * GAP, "敌对加成", AimConfig.TIER_HOSTILE_STEPS,
                v -> String.format(Locale.ROOT, "+%.1f", v),
                () -> AimConfig.tierBonusHostile, v -> AimConfig.tierBonusHostile = v);
        row++;

        addBool(right, top + row * GAP, "要求玩家移动",
                v -> v ? "开" : "关",
                () -> AimConfig.requireMovement, v -> AimConfig.requireMovement = v);
        row++;

        addNum(right, top + row * GAP, "移动阈值", AimConfig.MOVE_THRESHOLD_STEPS,
                v -> String.format(Locale.ROOT, "%.2f 格/tick", v),
                () -> AimConfig.moveThreshold, v -> AimConfig.moveThreshold = v);
        row++;

        addBool(right, top + row * GAP, "视线检查",
                v -> v ? "开" : "关",
                () -> AimConfig.requireLineOfSight, v -> AimConfig.requireLineOfSight = v);
        row++;

        addBool(right, top + row * GAP, "忽略隐身目标",
                v -> v ? "开" : "关",
                () -> AimConfig.ignoreInvisible, v -> AimConfig.ignoreInvisible = v);
        row++;

        addNum(right, top + row * GAP, "死区", AimConfig.DEADZONE_STEPS,
                v -> v <= 0.0D ? "关" : String.format(Locale.ROOT, "%.2f°", v),
                () -> AimConfig.deadzone, v -> AimConfig.deadzone = v);
        row++;

        addNum(right, top + row * GAP, "输出平滑", AimConfig.SMOOTHING_STEPS,
                v -> v <= 0.0D ? "关" : String.format(Locale.ROOT, "%.2f", v),
                () -> AimConfig.smoothing, v -> AimConfig.smoothing = v);
        row++;

        addBool(right, top + row * GAP, "整数格吸附",
                v -> v ? "开（有台阶感）" : "关（平滑）",
                () -> AimConfig.snapToMouseGrid, v -> AimConfig.snapToMouseGrid = v);
        row++;

        addBool(right, top + row * GAP, "调试 HUD",
                v -> v ? "开" : "关",
                () -> AimConfig.debugHud, v -> AimConfig.debugHud = v);
        row++;

        addDrawableChild(ButtonWidget.builder(Text.literal("完成"), button -> this.close())
                .dimensions(right, top + row * GAP, COL_W, ROW_H).build());
    }

    private void addNum(int x, int y, String name, double[] steps, NumLabel label,
                        NumGetter getter, NumSetter setter) {
        addDrawableChild(ButtonWidget.builder(Text.literal(text(name, label.of(getter.get()))), button -> {
            setter.set(AimConfig.nextStep(steps, getter.get()));
            AimConfig.save();
            button.setMessage(Text.literal(text(name, label.of(getter.get()))));
        }).dimensions(x, y, COL_W, ROW_H).build());
    }

    private void addBool(int x, int y, String name, BoolLabel label,
                         BoolGetter getter, BoolSetter setter) {
        addDrawableChild(ButtonWidget.builder(Text.literal(text(name, label.of(getter.get()))), button -> {
            setter.set(!getter.get());
            AimConfig.save();
            button.setMessage(Text.literal(text(name, label.of(getter.get()))));
        }).dimensions(x, y, COL_W, ROW_H).build());
    }

    private static String text(String name, String value) {
        return name + "：" + value;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int top = Math.max(28, (this.height - ROWS * GAP) / 2 - 6);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title,
                this.width / 2, top - 22, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    private interface NumLabel {
        String of(double value);
    }

    private interface NumGetter {
        double get();
    }

    private interface NumSetter {
        void set(double value);
    }

    private interface BoolLabel {
        String of(boolean value);
    }

    private interface BoolGetter {
        boolean get();
    }

    private interface BoolSetter {
        void set(boolean value);
    }
}