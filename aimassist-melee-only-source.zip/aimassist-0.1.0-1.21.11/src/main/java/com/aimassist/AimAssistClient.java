package com.aimassist;

import com.aimassist.config.AimConfig;
import com.aimassist.core.AimController;
import com.aimassist.util.DebugHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AimAssistClient implements ClientModInitializer {

    public static final String MOD_ID = "aimassist";
    public static final Logger LOGGER = LoggerFactory.getLogger("AimAssist");

    public static final AimController CONTROLLER = new AimController();

    /** 供 Mixin 取灵敏度设置用。 */
    public static MinecraftClient client() {
        return MinecraftClient.getInstance();
    }

    public static void debug(String format, Object... args) {
        if (Edition.DEV) {
            LOGGER.info(format, args);
        }
    }

    @Override
    public void onInitializeClient() {
        AimConfig.load();

        ClientTickEvents.START_CLIENT_TICK.register(CONTROLLER::tick);
        HudElementRegistry.addLast(Identifier.of(MOD_ID, "debug_hud"), (context, tickCounter) -> DebugHud.render(context));

        LOGGER.info("[AimAssist] {} loaded: CLIENT-ONLY. Assist is additive; your own mouse input passes through.",
                Edition.TITLE);
    }
}
