package com.aimassist.mixin;

import com.aimassist.AimAssistClient;
import com.aimassist.core.AimController;
import com.aimassist.core.MouseDelta;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 在 Mouse.updateMouse 把 cursorDelta 换算成视角转角之前，把辅助修正量掺进去。
 *
 * <p>这个方法是<b>每渲染帧</b>调一次的（调用点在 MinecraftClient.render 里），
 * 所以整个控制器都在这里按帧跑：用当前朝向算误差、按帧时长折算这一帧该转多少度。
 * 只在 tick 里算、帧里分摊是不行的 —— 那样目标角仍是 20Hz 的阶跃，
 * 分摊得再匀也只是把台阶抹圆一点，画面依然是顿的。
 *
 * <p>delta 参数是<b>秒</b>（原版用它算鼠标速度），直接拿来做帧时长。
 *
 * <p>符号约定（已用字节码钉死）：原版 `changeLookDirection` 是
 * `pitch += cursorDeltaY * 0.15f`，而 `getRotationVector` 里 `y = -sin(pitch)`，
 * 所以 <b>pitch 正值为向下</b>，+cursorDeltaY 即低头。
 * 控制器给出的 deltaPitch 用的是同一套原版 pitch 约定（正值 = 向下），
 * 因此这里直接相加，<b>不要取负</b> —— 取负会让俯仰辅助变成正反馈、越推越远。
 */
@Mixin(Mouse.class)
public class MouseMixin {

    @Shadow
    private double cursorDeltaX;

    @Shadow
    private double cursorDeltaY;

    @Inject(method = "updateMouse(D)V", at = @At("HEAD"))
    private void aimassist$addAssistDelta(double delta, CallbackInfo ci) {
        MouseDelta.Correction correction = AimAssistClient.CONTROLLER.onFrame(delta);
        if (correction == null || correction.isZero()) {
            return;
        }
        cursorDeltaX += correction.rawX();
        cursorDeltaY += correction.rawY();
    }
}