package com.aimassist.core;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

public record TargetCandidate(
        Entity entity,
        String name,
        int tier,
        double distance,
        double angle,
        double angularSpeed,
        double yawRate,
        double score,
        Vec3d aimDirection,
        boolean lineOfSight) {

    public static final int TIER_PLAYER = 0;
    public static final int TIER_HOSTILE = 1;
    public static final int TIER_OTHER = 2;

    public String tierName() {
        return switch (tier) {
            case TIER_PLAYER -> "玩家";
            case TIER_HOSTILE -> "敌对";
            default -> "其他";
        };
    }

    /** HUD 用的一行摘要。 */
    public String describe() {
        return String.format("%s[%s] 距离=%.2f 夹角=%.1f° 角速=%.0f°/s 偏航=%+.0f°/s 分=%.3f%s",
                name, tierName(), distance, angle, angularSpeed, yawRate, score,
                lineOfSight ? "" : " (被挡)");
    }
}
