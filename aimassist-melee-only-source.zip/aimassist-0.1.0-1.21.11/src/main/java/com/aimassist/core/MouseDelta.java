package com.aimassist.core;

import net.minecraft.client.option.GameOptions;

/**
 * 把「这一帧要转多少度」换算成鼠标增量。
 *
 * <p>原版 Mouse.updateMouse 里：
 * <pre>
 *   d = 灵敏度 * 0.6 + 0.2;   f = d*d*d * 8
 *   yaw 增量 = cursorDeltaX * f * 0.15
 *   pitch 增量 = cursorDeltaY * f * 0.15
 * </pre>
 * 所以鼠标增量 = 角度 / (f * 0.15)。
 *
 * <p>默认<b>不做整数吸附</b>：注入值保持小数，画面才连续。整数吸附会让修正量
 * 在一帧只想转 0.1°、而一格是 0.6° 时取 0，于是变成「好几帧不动、然后跳一格」，
 * 正是要避免的台阶感。
 * <p>至于浮点精度：changeLookDirection 里是 (float)delta * 0.15f 的浮点乘，
 * 对小数增量误差约 1e-7 度，远小于一格，不会累积成静差。
 * <p>如果以后要贴合鼠标硬件的整数格（反作弊的 GCD 检查），把 snapToMouseGrid
 * 打开即可 —— 代价就是上面的台阶感。
 */
public final class MouseDelta {

    private MouseDelta() {
    }

    /** 灵敏度对应的角度/原值 系数，即原版那个 f * 0.15。 */
    public static double degreesPerRaw(GameOptions options) {
        double sensitivity = options.getMouseSensitivity().getValue();
        double d = sensitivity * 0.6D + 0.2D;
        double f = d * d * d * 8.0D;
        return f * 0.15D;
    }

    /** 鼠标原值单位 → 角度。 */
    public static double toDegrees(GameOptions options, double raw) {
        return raw * degreesPerRaw(options);
    }

    /**
     * @param deltaYaw   这一帧要转的偏航角（度），正数向右（= 原版 yaw 增大）
     * @param deltaPitch 这一帧要转的俯仰角（度），<b>正数向下</b>（原版 pitch 约定：+90 为直视下方）
     * @param snap       是否把原值吸附到整数格
     */
    public static Correction compute(GameOptions options, double deltaYaw, double deltaPitch, boolean snap) {
        double factor = degreesPerRaw(options);
        if (factor < 1.0E-9D) {
            return Correction.NONE;
        }

        double rawX = deltaYaw / factor;
        double rawY = deltaPitch / factor;

        if (snap) {
            rawX = Math.round(rawX);
            rawY = Math.round(rawY);
        }

        return new Correction(rawX, rawY, rawX * factor, rawY * factor);
    }

    /**
     * @param rawX     要加到 cursorDeltaX 的原值（可含小数）
     * @param rawY     要加到 cursorDeltaY 的原值（可含小数）
     * @param deltaYaw 实际会转过的偏航角（度）
     * @param deltaPitch 实际会转过的俯仰角（度）
     */
    public record Correction(double rawX, double rawY, double deltaYaw, double deltaPitch) {

        public static final Correction NONE = new Correction(0.0D, 0.0D, 0.0D, 0.0D);

        public boolean isZero() {
            return rawX == 0.0D && rawY == 0.0D;
        }
    }
}