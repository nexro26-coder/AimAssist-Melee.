package com.aimassist.core;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class AimMath {

    private AimMath() {
    }

    /**
     * 瞄准方向：<b>只对准碰撞箱中心的水平方位，Y 轴完全不参与</b>（用户 2026-09-25 拍板简化）。
     *
     * <p>返回的是单位水平方向（y 恒为 0），只用来算偏航误差。
     * <p><b>注意</b>：不要拿它去量距离 —— 它的模长恒为 1，距离必须用真实目标位置算。
     */
    public static Vec3d aimDirection(Vec3d eye, Box box) {
        Vec3d center = box.getCenter();
        double dx = center.x - eye.x;
        double dz = center.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 1.0E-6D) {
            return new Vec3d(0.0D, 0.0D, 1.0D);
        }
        return new Vec3d(dx / horizontal, 0.0D, dz / horizontal);
    }

    /**
     * 目标相对玩家的角速度（度/秒），<b>无符号</b>——只表示「难不难跟」，用于强度。
     * 只用相对速度里垂直于视线的那一部分 —— 正对着你冲过来的目标角速度接近 0，好跟；
     * 横向掠过的一样快却极难跟，这才是「难不难瞄」的真实度量。
     */
    public static double angularSpeed(Vec3d eye, Vec3d aimPoint, Vec3d relativeVelocity) {
        Vec3d toAim = aimPoint.subtract(eye);
        double distance = toAim.length();
        if (distance < 1.0E-4D) {
            return 0.0D;
        }
        Vec3d normal = toAim.multiply(1.0D / distance);
        Vec3d tangential = relativeVelocity.subtract(normal.multiply(relativeVelocity.dotProduct(normal)));
        return Math.toDegrees(tangential.length() / distance);
    }

    /**
     * 目标相对玩家的<b>偏航角速度</b>（度/秒，<b>有符号</b>），正数表示目标正在向「偏航角增大」的方向漂移。
     *
     * <p>前馈项必须用这个而不是 {@link #angularSpeed} —— 后者是无符号模长，
     * 拿它做前馈会变成「永远往同一个方向推」，从目标左侧接近时碰巧正确、
     * 从右侧接近时就会朝反方向远离（用户实测报过这个 bug）。
     *
     * <p>推导：yaw = atan2(-dx, dz)，对时间求导得 (hx·vz - hz·vx) / 水平距离，
     * 其中 h 是水平单位方向、v 是相对速度。
     */
    public static double yawRate(Vec3d eye, Vec3d target, Vec3d relativeVelocity) {
        double dx = target.x - eye.x;
        double dz = target.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 1.0E-4D) {
            return 0.0D;
        }
        double hx = dx / horizontal;
        double hz = dz / horizontal;
        return Math.toDegrees((hx * relativeVelocity.z - hz * relativeVelocity.x) / horizontal);
    }

    /** 由方向向量反算偏航角（与原版 getRotationVec 互为逆运算）。 */
    public static float yawOf(Vec3d dir) {
        return (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
    }

    public static double lerp(double delta, double start, double end) {
        return start + delta * (end - start);
    }
}
