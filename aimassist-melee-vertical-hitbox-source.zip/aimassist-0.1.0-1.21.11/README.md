# AimAssist

A **client-side** aim assist for Minecraft **1.21.11 (Fabric)**, made for players with disabilities.

It exists for the player who cannot aim reliably — the one who needs the game to meet them halfway. It nudges your crosshair toward a target inside a bubble around it, the way a controller's rotational aim assist does.

**Your own mouse input always passes through unchanged.** The assist adds a small rotation on top of whatever you did; it never blocks, slows down, or takes over your input. You can always pull the crosshair back off a target by moving your mouse.

![Minecraft](https://img.shields.io/badge/Minecraft-1.21.11-blue)
![Loader](https://img.shields.io/badge/Loader-Fabric-orange)
![Environment](https://img.shields.io/badge/Environment-Client--side-lightgrey)
![License](https://img.shields.io/badge/License-MIT-green)

---

## Design ground rules

1. **Fully client-side.** `fabric.mod.json` declares `"environment": "client"`, and only a `ClientModInitializer` is registered. There is no server entrypoint.
2. **No packets are constructed.** The assist writes into the same cursor-delta accumulator that your physical mouse writes into, and vanilla's own `Mouse.updateMouse` → `changeLookDirection` path applies it. Nothing is hand-built, nothing is sent directly.
3. **No `setYaw` / `setPitch` calls.** The rotation the server receives is produced by vanilla's own rotation path, exactly as it is for an unmodified client.
4. **Your input is never reduced.** There is no slowdown, no aim damping, and no dead zone on *your* input — the assist is purely additive. (A controller can afford slowdown because a stick is a vector signal; a mouse is a relative-position delta, where damping just feels broken.)
5. **The Y axis is not touched.** Only yaw is ever adjusted. Pitch is entirely yours.

## The bubble

Targets are picked from a **horizontal wedge** in front of you — not a 3D cone.

| Property | Meaning |
|---|---|
| Half-angle | `气泡夹角` — the horizontal bearing to the target must be within this many degrees of where you are looking |
| Length | `触发距离` — 3D distance from your eye to the entity's hitbox centre |

Because the trigger is a horizontal wedge, **pitch never affects whether the assist engages**. Looking down at the ground does not hide a target from it, and looking up does not reveal one.

Candidates are **players and mobs**. Players are weighted highest, then hostile mobs, then everything else.

**Target stickiness:** once the assist has a target, it keeps it as long as that target is still inside the bubble and visible. It only switches when a different target scores more than 1.15× higher. Without this, two similarly-scored mobs make the assist snap back and forth between them.

## How the control law runs

Two different rates, deliberately:

- **Target selection runs at tick rate (20 Hz)** — the entity list and movement state only change on ticks anyway.
- **The entire control law runs per render frame**, with the frame's own duration as `dt`, and the error recomputed from your *current* rotation every frame.

Running the law per frame is what makes the crosshair slide continuously. Computed at 20 Hz, the target bearing would arrive as steps; vanilla interpolates the camera, so those steps are visible as stutter no matter how the camera is smoothed afterwards.

Each frame:

```
error      = bearing to target − current yaw
P step     = error × (1 − exp(−pRate × strength × dt))     first-order approach
D step     = targetYawRate × strength × dt                 signed feedforward
step       = clamp(P + D, ±maxAssistSpeed × strength × dt)
step       = clamped so it never crosses the target
if |error| ≤ deadzone:  step = 0
step       = low-pass(step, smoothing)
```

Three details that matter:

- **P is a first-order approach, not a rate limit.** Writing it as `clamp(error, ±limit)` makes the step equal the whole error whenever the error is smaller than the limit — a 100 %-per-frame gain that fights your mouse near the centre and reads as jitter. `1 − exp(−k·dt)` removes a fixed *fraction* per frame, so the step goes to zero as the error does, and convergence is independent of frame rate.
- **D is a feedforward, so its gain is order 1.** It compensates the angle the target drifted *this frame*. Multiplying it by a speed cap inflates it by orders of magnitude and turns it into a bang-bang "jump to the target" command.
- **D must use the signed yaw rate.** Using the unsigned angular speed pushes in one direction forever — the assist then works when you approach from the target's left and pushes *away* when you approach from the right.

**Strength** scales both terms:

```
strength = assistCap × (strengthFloor + (1 − strengthFloor) × clamp(ω / ωRef, 0, 1))
```

where `ω` is the target's angular speed relative to you. Faster relative motion means a stronger assist. `strengthFloor` is what keeps this from being a binary switch: without a floor, a stationary target gets 0 % and any target that moves at all saturates instantly, so the assist appears to jump from nothing to full the moment something is knocked back.

## Settings

Everything is configurable in-game through **ModMenu**, and stored in `config/aimassist.properties`.

| Setting | Default | Notes |
|---|---|---|
| Enabled | on | Master switch |
| Assist strength cap | 100 % | Overall multiplier on both terms |
| Max assist speed | 260 °/s | Hard ceiling on the assist's own rate |
| Saturation speed | 250 °/s | Relative angular speed at which strength reaches full |
| Strength floor | 25 % | Strength at zero relative motion |
| Convergence rate | 50 /s | P term; lower is softer, higher is crisper |
| Trigger distance | 6.0 blocks | |
| Bubble half-angle | 7.0° | Horizontal only |
| Exit hysteresis | ×1.25 | Extra angle a current target may drift before it is dropped |
| Distance / angle weight | 0.5 / 0.5 | Target scoring |
| Player / hostile bonus | +0.40 / +0.20 | Target scoring |
| Require player movement | on | Assist only engages while you are moving |
| Movement threshold | 0.01 blocks/tick | |
| Line of sight | on | |
| Ignore invisible | on | |
| Snap to mouse grid | off | Rounds the injected value to whole cursor units |
| Dead zone | 1.0° | Inside this, the assist does nothing |
| Output smoothing | 0.10 | Low-pass on the final step; 0 disables it |
| Debug HUD | dev builds only | |

## Requirements

- Minecraft **1.21.11**, Fabric Loader ≥ 0.19.0, Java 21
- **Fabric API** (required)
- **ModMenu** (optional — only needed to open the settings screen)

## Building

```
./dev.ps1 build      # -> build/libs/aimassist-0.1.0+1.21.11.jar
./dev.ps1 runClient  # dev client
```

## A note on servers

This is an assist, and on most public multiplayer servers third-party assist mods are against the rules regardless of how conservatively they are implemented. The intent here is to give players with disabilities a way to participate at all — please respect the rules of whatever server you play on.

## License

MIT


### Hỗ trợ trục dọc (Pitch Assist)

Bản tùy chỉnh bổ sung tùy chọn `Hỗ trợ trục dọc`. Khi bật, mod chỉ hiệu chỉnh pitch nếu tia nhìn tại khoảng cách ngang tới mục tiêu nằm ngoài chiều cao hitbox: kéo về đỉnh hitbox khi ngắm quá cao, hoặc về đáy hitbox khi ngắm quá thấp. Nếu tia nhìn đã nằm trong khoảng đáy–đỉnh hitbox, mod không tự kéo pitch về tâm mục tiêu. Tùy chọn được lưu bằng khóa `verticalAssist` trong `config/aimassist.properties` và mặc định bật.
