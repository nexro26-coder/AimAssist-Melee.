package com.aimassist.config;

import com.aimassist.Edition;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class AimConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger("AimAssist");
    private static final String FILE_NAME = "aimassist.properties";

    public static final double[] RANGE_STEPS = {2.0D, 3.0D, 4.0D, 6.0D, 8.0D, 12.0D, 16.0D};
    public static final double[] FOV_STEPS = {4.0D, 7.0D, 10.0D, 12.0D, 16.0D, 22.0D, 30.0D};
    public static final double[] SPEED_STEPS = {60.0D, 90.0D, 120.0D, 180.0D, 260.0D, 360.0D, 450.0D, 500.0D, 550.0D, 600.0D};
    public static final double[] CAP_STEPS = {0.15D, 0.25D, 0.40D, 0.55D, 0.75D, 1.00D};
    public static final double[] OMEGA_REF_STEPS = {30.0D, 60.0D, 120.0D, 250.0D, 400.0D, 600.0D};
    public static final double[] HYSTERESIS_STEPS = {1.00D, 1.25D, 1.50D, 2.00D};
    public static final double[] WEIGHT_STEPS = {0.0D, 0.1D, 0.2D, 0.3D, 0.4D, 0.5D, 0.6D, 0.7D, 0.8D, 0.9D, 1.0D};
    public static final double[] TIER_PLAYER_STEPS = {0.0D, 0.1D, 0.2D, 0.3D, 0.4D, 0.6D, 0.8D};
    public static final double[] TIER_HOSTILE_STEPS = {0.0D, 0.1D, 0.2D, 0.3D, 0.5D};
    public static final double[] MOVE_THRESHOLD_STEPS = {0.01D, 0.03D, 0.05D, 0.10D, 0.20D};
    public static final double[] STRENGTH_FLOOR_STEPS = {0.0D, 0.25D, 0.5D, 0.75D, 1.0D};
    public static final double[] P_RATE_STEPS = {8.0D, 12.0D, 18.0D, 30.0D, 50.0D, 80.0D, 120.0D, 180.0D, 240.0D, 300.0D, 400.0D, 500.0D, 600.0D};
    public static final double[] DEADZONE_STEPS = {0.0D, 0.1D, 0.25D, 0.5D, 1.0D};
    public static final double[] SMOOTHING_STEPS = {
            0.0D, 0.05D, 0.10D, 0.15D, 0.20D, 0.25D, 0.30D,
            0.35D, 0.40D, 0.45D, 0.50D};

    /** 在档位表里取下一个值；当前值不在表里就取第一个比它大的。 */
    public static double nextStep(double[] steps, double current) {
        for (int i = 0; i < steps.length; i++) {
            if (Math.abs(steps[i] - current) < 1.0E-6D) {
                return steps[(i + 1) % steps.length];
            }
        }
        for (double step : steps) {
            if (step > current) {
                return step;
            }
        }
        return steps[0];
    }

    public static boolean enabled = true;

    /** 仅在主手持有近战武器时启用辅助。 */
    public static boolean requireMeleeWeapon = true;
    public static boolean debugHud = Edition.DEV;

    /** 气泡长度（格）。不再受原版攻击距离压制，可以预瞄远处目标。 */
    public static double range = 6.0D;

    /** 气泡半角（度）。 */
    public static double fov = 7.0D;

    /** 已选中的目标允许用更宽的夹角退出，避免在气泡边界反复开关。 */
    public static double exitHysteresis = 1.25D;

    public static double weightDistance = 0.5D;
    public static double weightAngle = 0.5D;

    public static double tierBonusPlayer = 0.40D;
    public static double tierBonusHostile = 0.20D;

    /** 辅助强度上限，相对玩家自己能达到的最大转速。 */
    public static double assistCap = 1.00D;

    /** 辅助单 tick 能贡献的最大角速度（度/秒）。 */
    public static double maxAssistSpeed = 260.0D;

    /** 达到这个角速度（度/秒）时辅助拉满。 */
    public static double omegaRef = 250.0D;

    /**
     * 强度下限：目标静止（相对角速度 0）时也至少给这么多比例的强度。
     *
     * <p>0 = 纯速度依赖（静止完全不帮，一动就满，会突然从 0 跳到上限）；
     * 0.5 = 静止给一半力，速度把它推到满；1 = 恒定满强度（取消速度依赖）。
     */
    public static double strengthFloor = 0.25D;

    /** P 项收敛速率（1/秒）。越低越柔和，越高越干脆。 */
    public static double pRate = 50.0D;

    /**
     * 死区（度）：误差小于它就完全不介入。切掉指数逼近「越靠近越慢」的长尾，
     * 同时消掉中心附近的微抖。0 = 关闭。
     */
    public static double deadzone = 1.0D;

    /** 输出低通强度：0 = 关闭（原始输出），越大越平滑、延迟也越大。 */
    public static double smoothing = 0.1D;

    public static boolean requireMovement = true;
    public static double moveThreshold = 0.01D;

    public static boolean requireLineOfSight = true;
    public static boolean ignoreInvisible = true;

    /** 关闭 = 注入小数鼠标原值（画面连续）；打开 = 吸附到整数格（贴合鼠标硬件，但有台阶感）。 */
    public static boolean snapToMouseGrid = false;

    private AimConfig() {
    }

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }

    public static void load() {
        Path path = configPath();
        if (!Files.exists(path)) {
            LOGGER.info("[AimAssist] no config yet, writing defaults to {}", path);
            save();
            return;
        }
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
        } catch (IOException e) {
            LOGGER.warn("[AimAssist] failed to read config, using defaults: {}", e.toString());
            return;
        }

        enabled = readBool(props, "enabled", enabled);
        requireMeleeWeapon = readBool(props, "requireMeleeWeapon", requireMeleeWeapon);
        debugHud = readBool(props, "debugHud", debugHud);
        requireMovement = readBool(props, "requireMovement", requireMovement);
        requireLineOfSight = readBool(props, "requireLineOfSight", requireLineOfSight);
        ignoreInvisible = readBool(props, "ignoreInvisible", ignoreInvisible);
        snapToMouseGrid = readBool(props, "snapToMouseGrid", snapToMouseGrid);

        range = readDouble(props, "range", range);
        fov = readDouble(props, "fov", fov);
        exitHysteresis = readDouble(props, "exitHysteresis", exitHysteresis);
        weightDistance = readDouble(props, "weightDistance", weightDistance);
        weightAngle = readDouble(props, "weightAngle", weightAngle);
        tierBonusPlayer = readDouble(props, "tierBonusPlayer", tierBonusPlayer);
        tierBonusHostile = readDouble(props, "tierBonusHostile", tierBonusHostile);
        assistCap = readDouble(props, "assistCap", assistCap);
        maxAssistSpeed = readDouble(props, "maxAssistSpeed", maxAssistSpeed);
        omegaRef = readDouble(props, "omegaRef", omegaRef);
        strengthFloor = readDouble(props, "strengthFloor", strengthFloor);
        pRate = readDouble(props, "pRate", pRate);
        deadzone = readDouble(props, "deadzone", deadzone);
        smoothing = readDouble(props, "smoothing", smoothing);
        moveThreshold = readDouble(props, "moveThreshold", moveThreshold);

        LOGGER.info("[AimAssist] config loaded: enabled={} hud={} range={} fov={} cap={} speed={}",
                enabled, debugHud, range, fov, assistCap, maxAssistSpeed);

        save();
    }

    public static void save() {
        Properties props = new Properties();
        props.setProperty("enabled", String.valueOf(enabled));
        props.setProperty("requireMeleeWeapon", String.valueOf(requireMeleeWeapon));
        props.setProperty("debugHud", String.valueOf(debugHud));
        props.setProperty("range", String.valueOf(range));
        props.setProperty("fov", String.valueOf(fov));
        props.setProperty("exitHysteresis", String.valueOf(exitHysteresis));
        props.setProperty("weightDistance", String.valueOf(weightDistance));
        props.setProperty("weightAngle", String.valueOf(weightAngle));
        props.setProperty("tierBonusPlayer", String.valueOf(tierBonusPlayer));
        props.setProperty("tierBonusHostile", String.valueOf(tierBonusHostile));
        props.setProperty("assistCap", String.valueOf(assistCap));
        props.setProperty("maxAssistSpeed", String.valueOf(maxAssistSpeed));
        props.setProperty("omegaRef", String.valueOf(omegaRef));
        props.setProperty("strengthFloor", String.valueOf(strengthFloor));
        props.setProperty("pRate", String.valueOf(pRate));
        props.setProperty("deadzone", String.valueOf(deadzone));
        props.setProperty("smoothing", String.valueOf(smoothing));
        props.setProperty("requireMovement", String.valueOf(requireMovement));
        props.setProperty("moveThreshold", String.valueOf(moveThreshold));
        props.setProperty("requireLineOfSight", String.valueOf(requireLineOfSight));
        props.setProperty("ignoreInvisible", String.valueOf(ignoreInvisible));
        props.setProperty("snapToMouseGrid", String.valueOf(snapToMouseGrid));
        try (OutputStream out = Files.newOutputStream(configPath())) {
            props.store(out, "AimAssist - client-side aim assist");
        } catch (IOException e) {
            LOGGER.warn("[AimAssist] failed to write config: {}", e.toString());
        }
    }

    private static boolean readBool(Properties props, String key, boolean fallback) {
        String raw = props.getProperty(key);
        return raw == null ? fallback : Boolean.parseBoolean(raw);
    }

    private static double readDouble(Properties props, String key, double fallback) {
        try {
            return Double.parseDouble(props.getProperty(key, String.valueOf(fallback)));
        } catch (NumberFormatException e) {
            LOGGER.warn("[AimAssist] bad {} in config, keeping {}", key, fallback);
            return fallback;
        }
    }
}
