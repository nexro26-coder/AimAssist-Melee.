package com.aimassist.core;

import com.aimassist.config.AimConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/**
 * 气泡选目标 + P/D 控制律。
 *
 * <p>两层节奏：<b>选目标在 tick</b>（实体列表、移动状态本来就按 tick 变），
 * <b>控制律在渲染帧</b>（误差要用当前朝向算，按帧时长折算这一帧该转多少度）。
 * 只有在帧里算，准星才是连续滑过去；放 tick 里算的话目标角是 20Hz 阶跃，
 * 画面再怎么插值也是顿的。
 *
 * <p>触发范围 = 绕视轴的水平楔形（半角 fov、长度 range），<b>Y 轴不参与</b>；
 * 瞄准同样只对准目标碰撞箱中心的水平方位，俯仰完全不注入。
 */
public class AimController {

    private static final int HUD_MAX_CANDIDATES = 6;

    /** 换目标需要新目标分数超过当前目标的比例，避免在分数接近的两个目标之间来回跳。 */
    private static final double SWITCH_MARGIN = 1.15D;

    private final List<TargetCandidate> candidates = new ArrayList<>();

    private TargetCandidate selected;

    private Entity lastSelectedEntity;

    /** 输出低通的状态。必须跨帧保留，否则每个 tick 只有 3~4 帧可平滑，等于没滤。 */
    private double smoothedStepYaw;

    private String statusText = "Đang chờ";

    private double bubbleRadiusPixels;

    private double playerSpeed;

    private boolean playerMoving;

    private double assistScale;

    private MouseDelta.Correction lastCorrection = MouseDelta.Correction.NONE;

    private double lastPRate;

    private double lastDRate;

    private int framesThisTick;

    private int framesLastTick;

    public void tick(MinecraftClient client) {
        framesLastTick = framesThisTick;
        framesThisTick = 0;

        candidates.clear();
        selected = null;
        bubbleRadiusPixels = computeBubbleRadiusPixels(client);
        lastCorrection = MouseDelta.Correction.NONE;

        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) {
            statusText = "Không tìm thấy người chơi hoặc thế giới";
            lastSelectedEntity = null;
            return;
        }
        if (client.currentScreen != null) {
            statusText = "Đang mở giao diện";
            lastSelectedEntity = null;
            return;
        }
        if (AimConfig.requireMeleeWeapon && !isHoldingMeleeWeapon(player.getMainHandStack())) {
            statusText = "Chưa cầm vũ khí cận chiến";
            lastSelectedEntity = null;
            smoothedStepYaw = 0.0D;
            return;
        }

        Vec3d velocity = player.getVelocity();
        playerSpeed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        playerMoving = playerSpeed > AimConfig.moveThreshold;

        Vec3d eye = player.getEyePos();
        double range = AimConfig.range;
        double fov = AimConfig.fov;

        Box search = player.getBoundingBox().expand(range);
        for (Entity entity : client.world.getOtherEntities(player, search)) {
            if (!isCandidate(entity)) {
                continue;
            }
            Box box = entity.getBoundingBox();
            // 筛选/距离/角速度用真实的三维位置（实体中心），否则低头看目标时
            // 水平瞄准方向与视线的夹角会虚高，目标会被气泡误拒。
            Vec3d center = box.getCenter();
            Vec3d toCenter = center.subtract(eye);
            double distance = toCenter.length();
            if (distance > range) {
                continue;
            }

            // 触发只看水平方位角 —— 瞄准不参与 Y 轴，触发也不该参与。
            // 用三维夹角会把俯仰算进来，低头看目标时会被误判为超出范围。
            double angle = Math.abs(wrapDegrees(AimMath.yawOf(toCenter) - player.getYaw()));
            boolean isCurrent = entity == lastSelectedEntity;
            double angleLimit = isCurrent ? fov * AimConfig.exitHysteresis : fov;
            if (angle > angleLimit) {
                continue;
            }

            Vec3d relativeVelocity = entity.getVelocity().subtract(velocity);
            double omega = AimMath.angularSpeed(eye, center, relativeVelocity);
            double yawRate = AimMath.yawRate(eye, center, relativeVelocity);
            boolean lineOfSight = !AimConfig.requireLineOfSight || hasLineOfSight(player, entity);
            int tier = tierOf(entity);

            double score = AimConfig.weightDistance * (1.0D - distance / range)
                    + AimConfig.weightAngle * (1.0D - angle / angleLimit)
                    + tierBonus(tier);

            // 瞄准方向：只取实体中心的水平方位，Y 轴不参与。
            Vec3d aimDir = AimMath.aimDirection(eye, box);

            candidates.add(new TargetCandidate(entity, entity.getName().getString(), tier,
                    distance, angle, omega, yawRate, score, aimDir, lineOfSight));
        }

        candidates.sort((a, b) -> Double.compare(b.score(), a.score()));

        // 目标保持：多目标并存时，若只是「别家分略高」就切换，视角会被反复甩向
        // 不同的生物（表现为严重偏离、来回跳）。所以当前目标只要还在气泡内就留着，
        // 只有新目标明显更优（超过 switchMargin）才允许换。
        TargetCandidate held = null;
        if (lastSelectedEntity != null) {
            for (TargetCandidate candidate : candidates) {
                if (candidate.entity() == lastSelectedEntity && candidate.lineOfSight()) {
                    held = candidate;
                    break;
                }
            }
        }

        TargetCandidate best = null;
        for (TargetCandidate candidate : candidates) {
            if (candidate.lineOfSight()) {
                best = candidate;
                break;
            }
        }

        if (held != null && (best == null || best == held
                || best.score() < held.score() * SWITCH_MARGIN)) {
            selected = held;
        } else {
            selected = best;
        }
        Entity previousSelection = lastSelectedEntity;
        lastSelectedEntity = selected == null ? null : selected.entity();
        if (lastSelectedEntity != previousSelection) {
            smoothedStepYaw = 0.0D;
        }

        statusText = describeStatus();
    }

    /**
     * 每个渲染帧调一次，返回这一帧要注入的鼠标增量。
     *
     * @param deltaSeconds 帧时长（秒），原版 Mouse.updateMouse 的参数
     */
    public MouseDelta.Correction onFrame(double deltaSeconds) {
        framesThisTick++;
        lastCorrection = MouseDelta.Correction.NONE;

        if (gated() || deltaSeconds <= 0.0D) {
            smoothedStepYaw = 0.0D;
            return null;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return null;
        }

        Vec3d eye = player.getEyePos();
        Vec3d aimDir = selected.aimDirection();
        if (aimDir.lengthSquared() < 1.0E-8D) {
            return null;
        }

        // Y 轴不参与：只算偏航误差，俯仰完全不注入。
        double errorYaw = wrapDegrees(AimMath.yawOf(aimDir) - player.getYaw());

        // 强度：速度项只负责「把下限推到满」，下限本身保证静止时也有稳定的助力。
        // 没有下限时 ω=0 给 0、ω 稍大就撞顶（击退速度约 458°/s，阈值只有 30），
        // 于是「静止完全没辅助、一动就满」——表现为攻击生物后突然变强。
        double speedFactor = MathHelper.clamp(selected.angularSpeed() / AimConfig.omegaRef, 0.0D, 1.0D);
        double scale = AimConfig.assistCap
                * (AimConfig.strengthFloor + (1.0D - AimConfig.strengthFloor) * speedFactor);
        assistScale = scale;

        // P 项：一阶指数逼近，每帧只消除固定比例（由时间常数决定），与帧率无关。
        // 关键是误差 → 0 时步长也 → 0，不会出现「每帧把误差整个吃掉」的无穷增益
        // —— 那个才是准星靠近中心线时抖动的根源。
        double pAlpha = 1.0D - Math.exp(-AimConfig.pRate * scale * deltaSeconds);
        double pStepYaw = errorYaw * pAlpha;

        // D 项：有符号的偏航角速度前馈，只补偿「目标这一帧漂移了多少角度」。
        // 增益是 1 量级 —— 不能乘 maxAssistSpeed，那会把前馈放大几个数量级，
        // 退化成 bang-bang（每帧直接跳到目标），同样表现为抖动。
        // 也必须用有符号的 yawRate：用无符号的 angularSpeed 会永远朝同一方向推。
        double dStepYaw = selected.yawRate() * scale * deltaSeconds;

        double maxStep = AimConfig.maxAssistSpeed * scale * deltaSeconds;
        // 先夹速度上限，再夹住「不得越过目标点」。
        double stepYaw = MathHelper.clamp(pStepYaw + dStepYaw, -maxStep, maxStep);
        stepYaw = errorYaw > 0.0D ? Math.min(stepYaw, errorYaw) : Math.max(stepYaw, errorYaw);

        // 死区：已经够接近中心就完全撒手。指数逼近在误差小时会拖出一条
        // 「越靠近越慢」的长尾，死区把这条尾巴切掉，同时消掉中心附近的微抖。
        if (AimConfig.deadzone > 0.0D && Math.abs(errorYaw) <= AimConfig.deadzone) {
            stepYaw = 0.0D;
        }

        // 输出低通：这一帧的步长和上一帧混合，压掉高频抖动。代价是延迟。
        if (AimConfig.smoothing > 0.0D) {
            double tau = AimConfig.smoothing * 0.15D;
            double alpha = 1.0D - Math.exp(-deltaSeconds / tau);
            smoothedStepYaw += (stepYaw - smoothedStepYaw) * alpha;
            stepYaw = smoothedStepYaw;
        } else {
            smoothedStepYaw = stepYaw;
        }

        double stepPitch = 0.0D;

        lastPRate = pStepYaw / deltaSeconds;
        lastDRate = dStepYaw / deltaSeconds;

        MouseDelta.Correction correction = MouseDelta.compute(
                client.options, stepYaw, stepPitch, AimConfig.snapToMouseGrid);
        lastCorrection = correction;
        return correction;
    }

    /** 本帧是否应该「不介入」。 */
    private boolean gated() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!AimConfig.enabled || selected == null) {
            return true;
        }
        if (AimConfig.requireMeleeWeapon && (client.player == null
                || !isHoldingMeleeWeapon(client.player.getMainHandStack()))) {
            return true;
        }
        if (AimConfig.requireMovement && !playerMoving) {
            return true;
        }
        return AimConfig.assistCap <= 0.0D;
    }

    private String describeStatus() {
        if (!AimConfig.enabled) {
            return "Đã tắt";
        }
        if (candidates.isEmpty()) {
            return "Không có mục tiêu trong phạm vi";
        }
        if (selected == null) {
            return "Có mục tiêu nhưng bị khối chặn tầm nhìn";
        }
        if (AimConfig.requireMovement && !playerMoving) {
            return "Có mục tiêu nhưng người chơi đứng yên — không hỗ trợ";
        }
        if (selected.angularSpeed() <= 0.0D) {
            return "Đã chọn mục tiêu (mục tiêu đứng yên tương đối)";
        }
        return "Đang hỗ trợ ngắm";
    }

    /**
     * 通过物品类名识别原版近战武器，避免依赖不同小版本中可能变化的 ItemTags。
     * 同时兼容 1.21.11 的剑、斧、锤、三叉戟及长矛类武器。
     */
    private boolean isHoldingMeleeWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }

        // Dùng ID đăng ký của vật phẩm thay vì tên class Java. Tên class có thể
        // bị remap/obfuscate giữa môi trường phát triển và game đã đóng gói,
        // khiến điều kiện "chỉ cầm vũ khí" từ chối cả kiếm/rìu hợp lệ.
        String itemId = Registries.ITEM.getId(stack.getItem()).getPath()
                .toLowerCase(java.util.Locale.ROOT);
        return itemId.endsWith("_sword")
                || itemId.endsWith("_axe")
                || itemId.equals("mace")
                || itemId.equals("trident")
                || itemId.endsWith("_spear")
                || itemId.equals("spear");
    }

    /** 目标 = 玩家 + 生物。盔甲架之类不是 MobEntity，自动排除。 */
    private boolean isCandidate(Entity entity) {
        if (entity.isRemoved() || !entity.isAlive()) {
            return false;
        }
        if (AimConfig.ignoreInvisible && entity.isInvisible()) {
            return false;
        }
        if (entity instanceof PlayerEntity other) {
            return !other.isSpectator();
        }
        return entity instanceof MobEntity;
    }

    private int tierOf(Entity entity) {
        if (entity instanceof PlayerEntity) {
            return TargetCandidate.TIER_PLAYER;
        }
        if (entity instanceof Monster) {
            return TargetCandidate.TIER_HOSTILE;
        }
        return TargetCandidate.TIER_OTHER;
    }

    private double tierBonus(int tier) {
        return switch (tier) {
            case TargetCandidate.TIER_PLAYER -> AimConfig.tierBonusPlayer;
            case TargetCandidate.TIER_HOSTILE -> AimConfig.tierBonusHostile;
            default -> 0.0D;
        };
    }

    private boolean hasLineOfSight(ClientPlayerEntity player, Entity target) {
        Vec3d from = player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        HitResult hit = player.getEntityWorld().raycast(new RaycastContext(
                from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        return hit.getType() == HitResult.Type.MISS;
    }

    /**
     * 气泡边界的屏幕横向偏移。触发范围是绕视轴的水平楔形（Y 轴不参与），
     * 所以只有横向半宽有意义：r = (屏幕高/2) · tanθ / tan(fovY/2)，fovY 取游戏内垂直 FOV。
     */
    private double computeBubbleRadiusPixels(MinecraftClient client) {
        double fovY = client.options.getFov().getValue();
        int height = client.getWindow().getScaledHeight();
        double halfTan = Math.tan(Math.toRadians(fovY) * 0.5D);
        if (halfTan < 1.0E-6D) {
            return 0.0D;
        }
        return height * 0.5D * Math.tan(Math.toRadians(AimConfig.fov)) / halfTan;
    }

    private static double wrapDegrees(double degrees) {
        double wrapped = degrees % 360.0D;
        if (wrapped >= 180.0D) {
            wrapped -= 360.0D;
        }
        if (wrapped < -180.0D) {
            wrapped += 360.0D;
        }
        return wrapped;
    }

    public List<TargetCandidate> getCandidates() {
        return candidates;
    }

    public int getHudMaxCandidates() {
        return HUD_MAX_CANDIDATES;
    }

    public TargetCandidate getSelected() {
        return selected;
    }

    public String getStatusText() {
        return statusText;
    }

    public double getBubbleRadiusPixels() {
        return bubbleRadiusPixels;
    }

    public double getPlayerSpeed() {
        return playerSpeed;
    }

    public boolean isPlayerMoving() {
        return playerMoving;
    }

    public double getAssistScale() {
        return assistScale;
    }

    public MouseDelta.Correction getLastCorrection() {
        return lastCorrection;
    }

    public double getLastPRate() {
        return lastPRate;
    }

    public double getLastDRate() {
        return lastDRate;
    }

    public int getFramesLastTick() {
        return framesLastTick;
    }
}